package de.gymnasium_beetzendorf.vertretungsplan.fragment;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

/**
 * Created by David on 13.09.16.
 */
public class ScheduleTabFragment extends Fragment {

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }


}
