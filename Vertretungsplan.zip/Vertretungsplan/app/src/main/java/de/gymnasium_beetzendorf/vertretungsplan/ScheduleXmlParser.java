package de.gymnasium_beetzendorf.vertretungsplan;

/**
 * Created by davidfrenzel on 07/10/2016.
 */

public class ScheduleXmlParser {

    final String TAG = this.getClass().getSimpleName();


}
